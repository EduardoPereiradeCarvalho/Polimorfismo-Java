package SobrecargaOverload;

public class Calculadora {
	public int calcula(int x, int y) {
		return x + y;
	}
	public double calcula(double x, double y) {
		return x + y;
	}
	public String calcula(String x, String y) {
		return x + y;
	}
	public static void main(String args[]) {
		Calculadora calculo = new Calculadora();
		System.out.println(calculo.calcula(10,15));
		System.out.println(calculo.calcula(10.5, 9.7));
		System.out.println(calculo.calcula("Fala", "ram"));
	}
}
